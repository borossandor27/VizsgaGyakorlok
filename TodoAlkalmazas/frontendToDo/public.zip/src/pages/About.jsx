import React from 'react'

export default function About() {
  return (
    <div>
      <h1>Rólunk</h1>
      <p>Ez egy példa React alkalmazás a Vite használatával.</p>
    </div>
  )
}